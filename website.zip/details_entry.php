<?php
$servername="localhost";
$username="root";
$password="Mahadev@6062";
$database_name="database123";